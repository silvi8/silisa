<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pendaftaran Sertifikasi</title>
	 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	
<body>
	<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="SERTIFIKASI-brand" href="#">Sertifikasi</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
  <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        FORMULIR PENDAFTARAN SERTIFIKASI
                    </div>
                    <div class="card-body">
                        <form action="prosesform.php" method="POST">

                            <div class="mb-3">
                                <label for="nama_lengkap" class="form-label">ID PESERTA</label>
                                <input type="text" name="Peserta" class="form-control" id="Peserta" placeholder="masukan id peserta"required>
                            </div>

                            <div class="mb-3">
                                <label for="email_siswa" class="form-label">KD SKEMA</label>
                                <input type="text" name="Kd_skema" class="form-control" id="Kd_skema" placeholder="masukan kd skema"required>
                            </div>

                            <div class="mb-3">
                                <label for="tgl_lahir" class="form-label">NAMA PESERTA</label>
                                <input type="text" name="Nama_peserta" class="form-control" id="Nama_peserta" placeholder="masukan nama peserta"required>
                            </div>
                            <div class="mb-3">
                                <label for="asal_sekolah" class="form-label">JENIS KELAMIN</label>
                                <textarea class="form-control" name="Jenis_kelamin" id="Jenis_kelamin" rows="3" placeholder="masukan jenis kelamin"required></textarea>
                            </div> 
                            <div class="mb-3">
                                <label for="Alamat" class="form-label">ALAMAT</label>
                               <textarea class="form-control" name="Alamat" id="Alamat" rows="3" placeholder="masukan alamat"required></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="No_hp" class="form-label">NO HP</label>
                                <textarea class="form-control" name="No_hp" id="No_hp" rows="3" placeholder="masukan no hp"required></textarea>
                            </div>
                            
                            <button type="submit" value="submit" name="submit" class="btn btn-primary">Kirim Data</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
</body>
</html>
