<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Pendaftaran Sertifikasi</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container">
  	<a class="navbar-brand" href="#">
      <img src="images/logo.png" alt="Logo" width="30" height="24">
    </a>
    <a class="navbar-brand" href="#">Sertifikasi</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="form_reg.php">Pendaftaran</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Tentang</a>
        </li>
        
      </ul>
    </div>
  </div>
</nav>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      FORMULIR PENDAFTARAN SERTIFIKASI
    </div>
    <?php 
      if (isset($_SESSION['pesan'])) {
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>
              <?php echo $_SESSION['pesan']; ?>
          </strong> 
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php 
        session_destroy();
            }
    ?>
      <div class="card-body">
        <form action="aksi_reg.php" method="post">
        
        <div class="mb-3">
          <label for="nama" class="form-label">ID PESERTA</label>
          <input type="text" name="Id_peserta" class="form-control" id="Id_peserta" required>
        </div>
        <div class="mb-3">
          <label for="Kd_skema" class="form-label">KD SKEMA</label>
          <input type="text" name="Kd_skema" class="form-control" id="Kd_skema">
        </div>
        <div class="mb-3">
          <label for="asal_sekolah" class="form-label">NAMA PESERTA</label>
          <input type="text" name="Nama_peserta" class="form-control" id="Nama_peserta">
        </div>
        <div class="mb-3">
          <label for="alamat" class="form-label">JENIS KELAMIN</label>
          <input type="text" name="Jenis_kelamin" class="form-control" id="Jenis_kelamin">
        </div>
        <div class="mb-3">
          <label for="tahun_lulus" class="form-label">ALAMAT</label>
          <input type="text" name="Alamat" class="form-control" id="Alamat">
        </div>
        <div class="mb-3">
          <label for="tgl_daftar" class="form-label">NO HP</label>
          <input type="text" name="No_hp" class="form-control" id="No_hp">
        </div>
        <input type="submit" value="KIRIM" class="btn btn-primary">
        </form>
      </div>
    </div>
</div>