<?php

include "koneksi.php";


    // ambil data dari formulir
	$Id_peserta=$_POST["Id_peserta"];
	$Kd_skema=$_POST["Kd_skema"];
	$Nama_peserta=$_POST["Nama_peserta"];
	$Jenis_kelamin=$_POST["Jenis_kelamin"];
	$Alamat=$_POST["Alamat"];
	$No_hp=$_POST["No_hp"];

{

  // buat query
  $sql = "INSERT INTO dt_peserta (Id_peserta, Kd_skema, Nama_peserta, Jenis_Kelamin, Alamat, No_hp) 
  VALUE ('$Id_peserta', '$Kd_skema', '$Nama_peserta', '$Jenis_Kelamin', '$Alamat', '$No_hp' )";
  
  $query = mysqli_query($conn, $sql);
    if (!$query) {
        die('Query error: ' . mysqli_error($conn) . ' on line ' . __LINE__);
    }

  
    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: dashboard.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: dashboard.php?status=gagal');
    }  




?>


