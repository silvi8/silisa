<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Form Pendaftaran Sertifikasi</title>
	 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	
<body>
	<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="SERTIFIKASI-brand" href="#">SERTIFIKASI</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Tentang</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           
          </a>
            
          </ul>
        </li>
       
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<div class="container">
	<div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="image/slidesatu.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/slidedua.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="image/slidetiga.png" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-6">
			<h1>Uji kompetensi Web Programmer</h1>
			<p>Sertifikasi profesi merupakan upaya untuk memberikan pengakuan atas kompetensi yang
dikuasai seseorang sesuai dengan Standard Kompetensi Kerja Nasional Indonesia (SKKNI), standar
internasional atau standar khusus. Standar Kompetensi adalah pernyataan yang menguraikan
keterampilan, pengetahuan dan sikap yang harus dilakukan saat bekerja serta penerapannya,
sesuai dengan persyaratan yang ditetapkan oleh tempat kerja (industri).
Kompeten diartikan kemampuan dan kewenangan yang dimiliki oleh seseorang untuk melakukan
suatu pekerjaan yang didasari oleh pengetahuan, ketrampilan dan sikap sesuai dengan unjuk
kerja yang ditetapkan. Sertifikasi dilaksanakan dengan uji kompetensi melalui beberapa metode
uji oleh asesor yang dimiliki lisensi dari BNSP. Uji kompetensi dilaksanakan di Tempat Uji
Kompetensi (TUK). TUK LSP TIK Indonesia merupakan tempat kerja atau lembaga yang dapat
memberikan fasilitas pelaksanaan uji kompetensi yang telah diverifikasikan oleh LSP Tik Indonesia. </p>
</div>
<div class="col-6">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/yGMyMiUMKzc?si=MxWxH4EmrvWWddz_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
        	</iframe>
        </div>
    </div>
</div>


<div class="container">
    <h2>Galeri</h2>
    <div class="row">
        <div class="col-4">
        	<img src="image/foto1.png" class="img-thumbnail" alt="foto 1"></div>
        <div class="col-4">
        	<img src="image/foto2.png" class="img-thumbnail" alt="foto 2"></div>
        <div class="col-4">
        	<img src="image/foto3.png" class="img-thumbnail" alt="foto 3"></div>
    

    <div class="row">
        <div class="col-4">
        	<img src="image/foto4.png" class="img-thumbnail" alt="foto 4"></div>
        <div class="col-4">
        	<img src="image/foto5.png" class="img-thumbnail" alt="foto 5"></div>
        <div class="col-4">
        	<img src="image/foto6.png" class="img-thumbnail" alt="foto 6"></div>
    </div>
	</div>

</div>
<footer>
    <div class="container">
        <div class="row mt-5">
            <div class="col-6 ">
                <img src="image/logo.png" alt="logo">
                <h5>Digitech University</h5>
                <p>Kampus 1: Jalan Cibogo indah III - Bodogol Rt.08/05 Kel. Mekarjaya Kec. Rancasari Kota Bandung - Jawa Barat 40292 Kampus 2: Jalan Buah Batu No. 26 RT 003 RW 007 Kel. Burangrang Kec.Lengkong Kota Bandung - Jawa Barat 40262</p>
            </div>

            <div class="col-6">
                <h5>kontak kami</h5>
                <ul>
                    <li>admin@digitechuniveristy.ac.id</li>
                    <li>081-861-8611</li>
                    <li>022-7307967</li>
</body>
</html>